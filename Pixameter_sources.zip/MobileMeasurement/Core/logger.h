#ifndef _LOGGER_H
#define _LOGGER_H

#ifndef DEBUG
#define LOG(...)
#else
#define LOG(...) DDLogInfo(__VA_ARGS__)
#endif

#endif