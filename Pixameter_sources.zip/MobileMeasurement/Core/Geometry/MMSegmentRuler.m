//
//  MMSegmentRuler.m
//  MobileMeasurement
//
//  Created by Miroslav on 1/16/13.
//  Copyright (c) 2013 OCSICO. All rights reserved.
//

#import "MMSegmentRuler.h"
#import "MMState.h"
#import "MMColorPicker.h"

LOG_LEVEL_DECLARATION

@interface MMSegmentRuler ()

@property (nonatomic, strong, readwrite) UILabel *distLabel;

@end


@implementation MMSegmentRuler


@synthesize p1;
@synthesize p2;
@synthesize color;
@synthesize distLabel;


+ (MMSegmentRuler *)defaultRuler {
    
    MMSegmentRuler *ruler = [MMSegmentRuler new];
    ruler.p1 = CGPointMake(0,0);
    ruler.p2 = CGPointMake(0, 100);
    return ruler;
}

+ (MMSegmentRuler *)rulerWithBeginPoint:(CGPoint)p1 endPoint:(CGPoint)p2 {
    
    MMSegmentRuler *ruler = [MMSegmentRuler new];
    ruler.p1 = p1;
    ruler.p2 = p2;
    ruler.type = MMRulerAuto;
    return ruler;
}

- (id)init {
    
    self = [super init];
    
    if (self) {
        
        distLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [distLabel setTextAlignment:NSTextAlignmentCenter];
        [distLabel setBackgroundColor:[UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:0.5]];
        [distLabel setShadowColor:[UIColor blackColor]];
        [distLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:14.0]];
        
        self.color = [MMColorPicker colorsCollection][[MMState rulerColor]];
        self.system = [MMState rulerSystem];
        self.systemUnits = [MMState rulerSystemUnits];
        self.decimal = [MMState rulerDecimal];
        self.lineType = [MMState rulerLineType];
   }
    
    return self;
}

- (CGFloat)axisAngle {
    
    CGPoint v = CGPointMake(p2.x-p1.x,p2.y-p1.y);
    if (v.x == 0) return M_PI_2;
    if (v.y == 0) {
        
        if (v.x > 0) return 0;
        return M_PI;
    }
    if (v.y < 0) {
        
        v.x = -v.x;
        v.y = -v.y;
    }
    return acos(v.x/sqrt(v.x*v.x + v.y*v.y));
}

- (CGFloat)length {
    
    CGPoint v = CGPointMake(p1.x-p2.x,p1.y-p2.y);
    return sqrt(v.x*v.x + v.y*v.y);
}

-(NSString *)description{
    return [NSString stringWithFormat:@"%@ (%@, %@)", [super description],NSStringFromCGPoint(p1),NSStringFromCGPoint(p2)];
}

- (void)showInConsole {
    
    DDLogInfo(@"%@ %@",NSStringFromCGPoint(p1),NSStringFromCGPoint(p2));
}


CGPoint pointTranslatedFromRectToRect(CGPoint point, CGRect origRect, CGRect newRect){
    
    CGFloat xratio = newRect.size.width / origRect.size.width;
    CGFloat yratio = newRect.size.height / origRect.size.height;
    
    CGFloat translatedX = point.x - newRect.origin.x;
    CGFloat translatedY = point.y - newRect.origin.y;
    
    return CGPointMake(translatedX / xratio, translatedY / yratio);
}

-(MMSegmentRuler *)rulerTranslatedFromRect:(CGRect)origRect toRect:(CGRect)newRect{
    
    MMSegmentRuler* ruler = [[MMSegmentRuler alloc] init];
    
    ruler.p1 = pointTranslatedFromRectToRect(self.p1, origRect, newRect);
    ruler.p2 = pointTranslatedFromRectToRect(self.p2, origRect, newRect);
    ruler.color = self.color;
    ruler.decimal = self.decimal;
    ruler.system = self.system;
    ruler.systemUnits = self.systemUnits;
    ruler.lineType = self.lineType;
    ruler.group = self.group;
    ruler.name = self.name;
    ruler.note = self.note;
    ruler.type = self.type;
    ruler.value = self.value;
    ruler.calibration = self.calibration;
    
    return ruler;
}

- (MMRuler *)createRuler
{
    MMRuler *ruler = [[MMRuler alloc] init];
    ruler.p1 = self.p1;
    ruler.p2 = self.p2;
    ruler.color = self.color;
    ruler.decimal = self.decimal;
    ruler.system = self.system;
    ruler.systemUnits = self.systemUnits;
    ruler.lineType = self.lineType;
    ruler.group = self.group;
    ruler.name = self.name;
    ruler.note = self.note;
    ruler.type = self.type;
    ruler.value = self.value;
    ruler.calibration = self.calibration;
    return ruler;
}

#pragma mark - Copy

- (id)copyWithZone:(NSZone *)zone
{
    MMSegmentRuler *ruler = [[MMSegmentRuler alloc] init];
    ruler.p1 = self.p1;
    ruler.p2 = self.p2;
    ruler.color = self.color;
    ruler.lineType = self.lineType;
    ruler.decimal = self.decimal;
    ruler.system = self.system;
    ruler.systemUnits = self.systemUnits;
    ruler.group = self.group;
    ruler.name = self.name;
    ruler.note = self.note;
    ruler.type = self.type;
    ruler.value = self.value;
    ruler.calibration = self.calibration;
    return ruler;
}


#pragma mark - Calibration -

- (float)valueInMillimeters
{
    float value = self.value;
    switch (self.system) {
        case MMMetricSystem:
            switch (self.systemUnits) {
                case MMSantimeters:
                    value *= 10;
                    break;
                case MMMeters:
                    value *= 1000;
                    break;
                default:
                    break;
            }
            break;
        case MMEnglishSystem:
            switch (self.systemUnits) {
                case MMFoots:
                    value *= 304.8;
                    break;
                case MMYard:
                    value *= 914.4;
                    break;
                default:
                    value *= 25.4;
                    break;
            }
        default:
            break;
    }

    return value;
}

@end
