//
//  MMSegmentRuler.h
//  MobileMeasurement
//
//  Created by Miroslav on 1/16/13.
//  Copyright (c) 2013 OCSICO. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MMRuler.h"

@class MMRuler;

#define MMRulerMiddleHoleLength                         36
#define MMSegmentRulerBecomesSmallLength                60
#define MMRulerWidth                                   3.0
#define MMRulerEndsLength                               12
#define MMSmallRulerStemsLength                         30
#define MMLabelDistanceToSmallRuler                     20
#define MMRulerClickActivationLength                    30
#define MMRulerModifyPointActivationLength              15
#define MMRulerShiftActivationLength                    15
#define MMRulerCirclesRadius                            10

@interface MMSegmentRuler : NSObject <NSCopying> {
    
    CGPoint p1;
    CGPoint p2;
}

@property (nonatomic) CGPoint p1;
@property (nonatomic) CGPoint p2;
@property (nonatomic, strong, readonly) UILabel *distLabel;

@property (nonatomic, strong) NSString *group;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *note;
@property (nonatomic, strong) UIColor *color;

@property (nonatomic) NSInteger decimal;
@property (nonatomic) MMLineType lineType;
@property (nonatomic) MMSystemUnits systemUnits;
@property (nonatomic) MMSystem system;

@property (nonatomic) MMRulerType type;
@property (nonatomic) double value;

@property (nonatomic) BOOL calibration;

+ (MMSegmentRuler *)defaultRuler;
+ (MMSegmentRuler *)rulerWithBeginPoint:(CGPoint)p1 endPoint:(CGPoint)p2;

- (CGFloat)axisAngle;
- (CGFloat)length;

- (void)showInConsole;

- (MMSegmentRuler*) rulerTranslatedFromRect:(CGRect) origRect toRect:(CGRect)newRect;
- (MMRuler *)createRuler;

- (float)valueInMillimeters;

@end
