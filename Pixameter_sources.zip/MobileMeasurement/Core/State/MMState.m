//
//  MMState.m
//  MobileMeasurement
//
//  Created by Vitali on 9/6/12.
//  Copyright (c) 2012 OCSICO. All rights reserved.
//

#import "MMState.h"

#import "MMLocalization.h"
#import "MMColorPicker.h"


static MMState *instance;
static BOOL wasSettingsChanged = YES;
static BOOL wasInBackground = NO;


@implementation MMState


+ (MMState *)sharedInstance {
	
	if (instance == nil) {
		
		instance = [MMState new];
	}
	
	return instance;
}


- (id)init {
    
    self = [super init];
    
    if (self) {
        
    }
    
    return self;
}


#pragma mark - Public methods


+ (BOOL)wasSettingsChanged {
    
    return wasSettingsChanged;
}

+ (void)setSettingsChanged:(BOOL)changed {
    
    wasSettingsChanged = changed;
}

+ (BOOL)wasInBackground {
    
    return wasInBackground;
}

+ (void)setWasInBackground:(BOOL)was {
    
    wasInBackground = was;
}


+ (NSInteger)getDefaultLight {
    
    NSInteger i = [[NSUserDefaults standardUserDefaults] integerForKey:@"default light"];
    return i ? i : 4;
}

+ (void)setDefaultLight:(NSInteger)light {
    
    [[NSUserDefaults standardUserDefaults] setInteger:light forKey:@"default light"];
}

+ (NSInteger)getDefaultDistanceMeasurementMode {
    
    return [[NSUserDefaults standardUserDefaults] integerForKey:@"default distance measurement"];
}

+ (void)setDefaultDistanceMeasurementMode:(NSInteger)mode {
    
    [[NSUserDefaults standardUserDefaults] setInteger:mode forKey:@"default distance measurement"];
}

+ (NSInteger)getDefaultMeasurementRuler {
    
    return [[NSUserDefaults standardUserDefaults] integerForKey:@"default ruler"];
}

+ (void)setDefaultMeasurementRuler:(NSInteger)ruler {
    
    [[NSUserDefaults standardUserDefaults] setInteger:ruler forKey:@"default ruler"];
}

+ (NSInteger)getDefaultScale {
    
    return [[NSUserDefaults standardUserDefaults] integerForKey:@"default scale"];
}

+ (void)setDefaultScale:(NSInteger)scale {
    
    [[NSUserDefaults standardUserDefaults] setInteger:scale forKey:@"default scale"];
}

+ (BOOL)getDefaultCoplanarityCheck {
    
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"default coplanarity"];
}

+ (void)setDefaultCoplanarityCheck:(BOOL)check {
    
    [[NSUserDefaults standardUserDefaults] setBool:check forKey:@"default coplanarity"];
}

+ (BOOL)manualMode
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"manual mode"];
}

+ (void)setManualMode:(BOOL)state
{
    [[NSUserDefaults standardUserDefaults] setBool:state forKey:@"manual mode"];
}

+ (NSInteger)autoZoomCoefficient
{   NSInteger coeff = [[NSUserDefaults standardUserDefaults] integerForKey:@"autozoom coefficient"];
    return coeff ? coeff : 4;
}

+ (void)setAutoZoomCoefficient:(NSInteger)state
{
    [[NSUserDefaults standardUserDefaults] setInteger:state forKey:@"autozoom coefficient"];
}

#pragma mark - Ruler settings

+ (NSInteger)rulerDecimal
{
    return [[NSUserDefaults standardUserDefaults] integerForKey:@"default ruler decimal"];
}

+ (void)setRulerDecimal:(NSInteger)state
{
    [[NSUserDefaults standardUserDefaults] setInteger:state forKey:@"default ruler decimal"];
}

+ (MMSystem)rulerSystem
{
    return (MMSystem)[[NSUserDefaults standardUserDefaults] integerForKey:@"default ruler system"];
}

+ (void)setRulerSystem:(MMSystem)state
{
    [[NSUserDefaults standardUserDefaults] setInteger:state forKey:@"default ruler system"];
}

+ (MMSystemUnits)rulerSystemUnits
{
    return (MMSystemUnits)[[NSUserDefaults standardUserDefaults] integerForKey:@"default ruler units"];
}

+ (void)setRulerSystemUnits:(MMSystemUnits)state
{
    [[NSUserDefaults standardUserDefaults] setInteger:state forKey:@"default ruler units"];
}

+ (NSInteger)rulerColor
{
    return [[NSUserDefaults standardUserDefaults] integerForKey:@"default ruler color"];
}

+ (void)setRulerColor:(NSInteger)state
{
    [[NSUserDefaults standardUserDefaults] setInteger:state forKey:@"default ruler color"];
}

+ (MMLineType)rulerLineType
{
    return (MMLineType)[[NSUserDefaults standardUserDefaults] integerForKey:@"default ruler linetype"];
}

+ (void)setRulerLineType:(MMLineType *)state
{
    [[NSUserDefaults standardUserDefaults] setInteger:state forKey:@"default ruler linetype"];
}

+ (BOOL)gyroLeveling {
    return ![[NSUserDefaults standardUserDefaults] boolForKey:@"default gyro leveling"];
}

+ (void)setGyroLeveling:(BOOL)value {
    [[NSUserDefaults standardUserDefaults] setBool:!value forKey:@"default gyro leveling"];
}

+ (BOOL)alignmentPoints {
    return ![[NSUserDefaults standardUserDefaults] boolForKey:@"default aligment points"];
}

+ (void)setAlignmentPoints:(BOOL)value {
    [[NSUserDefaults standardUserDefaults] setBool:!value forKey:@"default aligment points"];
}


+ (void)defaults
{
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"default ruler defaults"] == NO)
    {
        [MMState setRulerColor:[[MMColorPicker colorsCollection] indexOfObject:[UIColor yellowColor]]];
        [MMState setRulerDecimal:1];
        [MMState setRulerSystem:MMMetricSystem];
        [MMState setRulerSystemUnits:MMMilimeters];
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"default ruler defaults"];
    }
}

#pragma mark - Private methods


#pragma mark - Memory management



@end
