//
//  MMState.h
//  MobileMeasurement
//
//  Created by Vitali on 9/6/12.
//  Copyright (c) 2012 OCSICO. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    MMFlashModeLight = 1,
    MMFlashModeOn = 2,
    MMFlashModeOff = 3,
    MMFlashModeAuto = 4,
} MMFlashMode;

@interface MMState : NSObject {
    
}

+ (MMState *)sharedInstance;

+ (BOOL)wasSettingsChanged;
+ (void)setSettingsChanged:(BOOL)changed;

+ (BOOL)wasInBackground;
+ (void)setWasInBackground:(BOOL)was;

+ (NSInteger)getDefaultLight;
+ (void)setDefaultLight:(NSInteger)light;

+ (NSInteger)getDefaultDistanceMeasurementMode;
+ (void)setDefaultDistanceMeasurementMode:(NSInteger)mode;

+ (NSInteger)getDefaultMeasurementRuler;
+ (void)setDefaultMeasurementRuler:(NSInteger)ruler;

+ (NSInteger)getDefaultScale; //!!!!! 0 - inches, 1 - millimeters
+ (void)setDefaultScale:(NSInteger)scale;

+ (BOOL)getDefaultCoplanarityCheck;
+ (void)setDefaultCoplanarityCheck:(BOOL)check;

+ (BOOL)manualMode;
+ (void)setManualMode:(BOOL)state;

+ (NSInteger)autoZoomCoefficient;
+ (void)setAutoZoomCoefficient:(NSInteger)state;

#pragma mark - Ruler settings

+ (NSInteger)rulerDecimal;
+ (void)setRulerDecimal:(NSInteger)state;

+ (MMSystem)rulerSystem;
+ (void)setRulerSystem:(MMSystem)state;

+ (MMSystemUnits)rulerSystemUnits;
+ (void)setRulerSystemUnits:(MMSystemUnits)state;

+ (NSInteger)rulerColor;
+ (void)setRulerColor:(NSInteger)state;

+ (MMLineType)rulerLineType;
+ (void)setRulerLineType:(MMLineType *)state;

+ (BOOL)gyroLeveling;
+ (void)setGyroLeveling:(BOOL)value;

+ (BOOL)alignmentPoints;
+ (void)setAlignmentPoints:(BOOL)value;

+ (void)defaults;

@end
