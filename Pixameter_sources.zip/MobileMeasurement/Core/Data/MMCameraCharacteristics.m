//
//  MMCameraCharacteristics.m
//  MobileMeasurement
//
//  Created by  Konstantin Salak on 12/11/13.
//  Copyright (c) 2013 Intellectsoft. All rights reserved.
//

#import "MMCameraCharacteristics.h"
#import "UIDevice+Hardware.h"

@implementation MMCameraCharacteristics

- (id)init
{
    self = [super init];
    if (self) {
        _zoom = 1.;
    }
    return self;
}

-(CGFloat)pixelSize{
    
    CGFloat fPixelSize = 1.75 * 0.001 * (self.imageCaptureSize.height / self.imageSize.height);
    

    // TODO: fix this in future
    if ([[UIDevice currentDevice] platformType] == UIDevice4SiPhone ||
        [[UIDevice currentDevice] platformType] == UIDevice5iPhone ||
        [[UIDevice currentDevice] platformType] == UIDevice5CiPhone) {
        
        fPixelSize = 1.4 * 0.001 * (self.imageCaptureSize.height / self.imageSize.height);
    }
    
    return fPixelSize;
}

-(void)setZoom:(CGFloat)zoom{
    _zoom = zoom;
}
@end
