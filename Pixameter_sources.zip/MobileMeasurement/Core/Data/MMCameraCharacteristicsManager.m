//
//  MMCameraCharacteristicsManager.m
//  MobileMeasurement
//
//  Created by Miroslav on 3/27/13.
//  Copyright (c) 2013 OCSICO. All rights reserved.
//

#import "MMCameraCharacteristicsManager.h"


static MMCameraCharacteristicsManager *instance;

@interface MMCameraCharacteristicsManager()

@property (nonatomic, strong) NSDictionary *settings;
@property (nonatomic, strong) NSString *key;

- (BOOL)load;

@end


@implementation MMCameraCharacteristicsManager


@synthesize settings;
@synthesize key;


+ (MMCameraCharacteristicsManager *)sharedInstance {
	
	if (!instance) {
		
		instance = [MMCameraCharacteristicsManager new];
	}
	
	return instance;
}


- (id)init {
	
	self = [super init];
	
	if (self) {
        
        self.key = [[UIDevice currentDevice] platformString];
        
        [self load];
	}
	
	return self;
}


#pragma mark - Serialization


- (BOOL)load {
	
    NSString *path = [[NSBundle mainBundle] pathForResource:@"Platforms" ofType:@"plist"];
    
	NSInputStream *stream = [NSInputStream inputStreamWithFileAtPath:path];
	
	[stream open];
	
	BOOL result = NO;
	
	id object = [NSPropertyListSerialization propertyListWithStream:stream options:NSPropertyListMutableContainersAndLeaves format:NULL error:nil];
	
	if ([object isKindOfClass:[NSMutableDictionary class]]) {
		
		NSDictionary *parameters = (NSMutableDictionary *)object;
        
        self.settings = parameters[key];
        
        if (!settings)
        {
            self.settings = parameters[@"iPad 3G"];
        }
		
		result = YES;
	}
	
	[stream close];
	
	return result;
}


#pragma mark - Public methods

-(MMCameraCharacteristics *)cameraCharacteristics{
    
    MMCameraCharacteristics* camera = [[MMCameraCharacteristics alloc] init];
    
    camera.displaySize = CGSizeMake(self.getDisplayWidth, self.getDisplayHeight);
    camera.sensorSize = CGSizeMake(0, self.getSensorHeight);
    camera.supportedImageSize = self.getSupportedImageSize;
    camera.focalLength = self.getFocalLength;
    camera.deviceThickness = self.getDeviceThickness;
    camera.imageCaptureSize = CGSizeMake(0, self.getImageCaptureHeight);
    camera.imageSize = CGSizeMake(0, self.getPixelImageHeight);
    
    return camera;
}

- (CGFloat)getDisplayWidth {
    
    return [settings[@"displayWidth"] doubleValue];
}

- (CGFloat)getDisplayHeight {
    
    return [settings[@"displayHeight"] doubleValue];
}

- (CGFloat)getFocalLength {
    
    return [settings[@"focalLength"] doubleValue];
}

- (CGFloat)getPixelImageHeight {
    
    return [settings[@"pixelImageHeight"] doubleValue];
}

- (CGFloat)getSensorHeight {
    
    return [settings[@"sensorHeight"] doubleValue];
}

- (CGFloat)getDeviceThickness {
    
    return [settings[@"thickness"] doubleValue];
}

- (CGFloat)getImageCaptureHeight {
    
    return [settings[@"imageCaptureHeight"] doubleValue];
}

- (CGSize)getSupportedImageSize {
    
    return CGSizeFromString(settings[@"supportedImageSize"]);
}

- (CGFloat)getAnimationDelay {
    
    return [settings[@"animationDelay"] doubleValue];
}

- (NSArray *)getAnimationImageNames {
    
    return settings[@"imageNames"];
}




#pragma mark - Memory management



@end
