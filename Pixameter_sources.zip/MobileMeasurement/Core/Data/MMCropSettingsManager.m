//
//  MMCropSettingsManager.m
//  
//
//  Created by User on 10/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MMCropSettingsManager.h"

#import "UIDevice+Hardware.h"

LOG_LEVEL_DECLARATION

static MMCropSettingsManager *instance;


@interface MMCropSettingsManager()

@property (nonatomic, strong) NSDictionary *settings;
@property (nonatomic, strong) NSString *key;

- (BOOL)load;

@end


@implementation MMCropSettingsManager


@synthesize settings;
@synthesize key;


+ (MMCropSettingsManager *)sharedInstance {
	
	if (!instance) {
		
		instance = [MMCropSettingsManager new];
	}
	
	return instance;
}


- (id)init {
	
	self = [super init];
	
	if (self) {
        
        self.key = [NSString stringWithFormat:@"%dx%dx%d", (int)UIScreen.mainScreen.bounds.size.width, (int)UIScreen.mainScreen.bounds.size.height, (int)UIScreen.mainScreen.scale];
        if ([[UIDevice currentDevice] platformType] == UIDeviceMiniiPad) key = [NSString stringWithFormat:@"%@(mini)",key];
        if ([[UIDevice currentDevice] platformType] == UIDevice4SiPhone) key = [NSString stringWithFormat:@"%@(s)",key];
        
        DDLogInfo(@"%@",key);
        [self load];
	}
	
	return self;
}


#pragma mark - Serialization


- (BOOL)load {
	
    NSString *path = [[NSBundle mainBundle] pathForResource:@"CropSettings" ofType:@"plist"];
    
	NSInputStream *stream = [NSInputStream inputStreamWithFileAtPath:path];
	
	[stream open];
	
	BOOL result = NO;
	
	id object = [NSPropertyListSerialization propertyListWithStream:stream options:NSPropertyListMutableContainersAndLeaves format:NULL error:nil];
	
	if ([object isKindOfClass:[NSMutableDictionary class]]) {
		
		NSDictionary *parameters = (NSMutableDictionary *)object;
        
        self.settings = parameters[key];
        
        if (!settings)
        {
            self.settings = parameters[@""];
        }
		
		result = YES;
	}
	
	[stream close];
	
	return result;
}


#pragma mark - Public methods


- (CGRect)getCropRect {
    
    return CGRectFromString(settings[@"cropRect"]);
}

- (NSString *)getSessionPreset {
    
    return settings[@"sessionPreset"];
}

- (CGSize)getSizeToFit {
    
    return CGSizeFromString(settings[@"sizeToFit"]);
}


#pragma mark - Memory management




@end
