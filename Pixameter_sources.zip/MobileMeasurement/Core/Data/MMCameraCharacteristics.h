//
//  MMCameraCharacteristics.h
//  MobileMeasurement
//
//  Created by  Konstantin Salak on 12/11/13.
//  Copyright (c) 2013 Intellectsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MMCameraCharacteristics : NSObject

@property (nonatomic, assign) CGSize displaySize;
@property (nonatomic, assign) CGSize sensorSize;
@property (nonatomic, assign) CGSize supportedImageSize;

@property (nonatomic, assign) CGSize imageCaptureSize;
@property (nonatomic, assign) CGSize imageSize;

@property (nonatomic, assign) CGFloat focalLength;
@property (nonatomic, assign) CGFloat deviceThickness;


@property (nonatomic, assign, readonly) CGFloat pixelSize;

@property (nonatomic, assign) CGFloat zoom;

@end
