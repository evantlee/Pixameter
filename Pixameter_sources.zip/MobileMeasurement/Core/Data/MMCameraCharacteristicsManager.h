//
//  MMCameraCharacteristicsManager.h
//  MobileMeasurement
//
//  Created by Miroslav on 3/27/13.
//  Copyright (c) 2013 OCSICO. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UIDevice+Hardware.h"
#import "MMCameraCharacteristics.h"

@interface MMCameraCharacteristicsManager : NSObject {
    
    NSDictionary *settings;
    NSString *key;
}

+ (MMCameraCharacteristicsManager *)sharedInstance;

-(MMCameraCharacteristics*) cameraCharacteristics;

//- (CGFloat)getDisplayWidth;
//- (CGFloat)getDisplayHeight;
//- (CGFloat)getFocalLength;
//- (CGFloat)getSensorHeight;
//- (CGSize)getSupportedImageSize;
//- (CGFloat)getDeviceThickness;
//- (CGFloat)getImageCaptureHeight;
//- (CGFloat)getPixelImageHeight;


- (CGFloat)getAnimationDelay;
- (NSArray *)getAnimationImageNames;


@end
