//
//  MMCalibrationValue.h
//  MobileMeasurement
//
//  Created by Алексей Шадура on 12.05.14.
//  Copyright (c) 2014 Intellectsoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MMSegmentRuler.h"

@interface MMCalibrationValue : NSObject <NSCopying>

@property (nonatomic,assign) CGPoint p1;
@property (nonatomic,assign) CGPoint p2;
@property (nonatomic,assign) float value;

- (instancetype)initWithRuler:(MMSegmentRuler *)ruler;
- (instancetype)initWithJSON:(NSString *)jsonString;
- (NSString *) jsonRepresentation;
- (CGSize)pixelSize;
- (void)translatePoints:(float)scale;

@end
