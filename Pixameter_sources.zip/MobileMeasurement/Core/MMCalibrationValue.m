//
//  MMCalibrationValue.m
//  MobileMeasurement
//
//  Created by Алексей Шадура on 12.05.14.
//  Copyright (c) 2014 Intellectsoft. All rights reserved.
//

#import "MMCalibrationValue.h"

LOG_LEVEL_DECLARATION

static NSString *const kCalibrationPoints = @"pp";
static NSString *const kCalibrationValue = @"cv";

@implementation MMCalibrationValue

-(instancetype)initWithRuler:(MMSegmentRuler *)ruler
{
    self = [super init];
    if (self)
    {
        self.p1 = ruler.p1;
        self.p2 = ruler.p2;
        self.value = ruler.valueInMillimeters;
    }
    
    return self;
}

#pragma mark - Serialization

-(NSString*) jsonRepresentation{
    NSError* err = nil;
    NSData* json = [NSJSONSerialization dataWithJSONObject:self.dictionaryRepresentation options:0 error:&err];
    
    if (err){
        DDLogInfo(@"error: %@", err.localizedDescription);
        return nil;
    }
    
    return [[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding];
}

-(NSDictionary *)dictionaryRepresentation{
    
    NSMutableDictionary* dict = [NSMutableDictionary dictionary];
    dict[kCalibrationPoints] = NSStringFromCGRect(CGRectMake(self.p1.x, self.p1.y, self.p2.x, self.p2.y));
    dict[kCalibrationValue] = [NSString stringWithFormat:@"%g",self.value];
    return dict;
}

- (instancetype)initWithJSON:(NSString *)jsonString
{
    self = [super init];
    if (self) {
        
        if (!jsonString){
            DDLogInfo(@"error: trying to create QRCode with nil data");
            return self;
        }
        
        NSData* jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
        NSError* err = nil;
        NSDictionary* dict = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&err];
        
        if (err){
            DDLogInfo(@"error: %@", err.localizedDescription);
            return self;
        }
        
        [self fillValuesWithDictionary:dict];
        
    }
    return self;
}

- (instancetype)initWithDictionary:(NSDictionary *)dictionary
{
    self = [super init];
    if (self) {
        
        [self fillValuesWithDictionary:dictionary];
        
    }
    
    return self;
}

-(void) fillValuesWithDictionary:(NSDictionary*) dict{
    
    
    CGRect points = CGRectFromString(dict[kCalibrationPoints]);
    self.p1  = CGPointMake(points.origin.x, points.origin.y);
    self.p2  = CGPointMake(points.size.width, points.size.height);
    
    self.value = [dict[kCalibrationValue] floatValue];
}

-(id)copyWithZone:(NSZone *)zone{
    
    MMCalibrationValue* copy = [[[self class] alloc] init];
    
    if (copy){
        copy.p1 = self.p1;
        copy.p2 = self.p2;
        copy.value = self.value;
    }
    
    return copy;
}

- (CGSize)pixelSize
{
    float points = sqrtf(powf(self.p2.x-self.p1.x, 2) + powf(self.p2.y-self.p1.y, 2));
    float value = self.value/points;
    CGSize size = CGSizeMake(value, value);
    return size;
}

- (void)translatePoints:(float)scale
{
    self.p1 = CGPointMake(self.p1.x*scale, self.p1.y*scale);
    self.p2 = CGPointMake(self.p2.x*scale, self.p2.y*scale);
}

@end
