//
//  MMLocalization.h
//  MobileMeasurement
//
//  Created by Vitali Lavrentikov on 7/28/12.
//

#import <Foundation/Foundation.h>


#define MMLocalizedString(key)              NSLocalizedString(key, nil)

// Code for custom localization can be here.
