//
//  NSArray(ISAdditions)
//
//  Created by Vladimir Burylov on 5/11/12.
//  Copyright (c) 2012 Intellectsoft LTD. All rights reserved.
//


#import "NSArray+ISAdditions.h"


@implementation NSArray (ISAdditions)

- (NSArray *) arrayByMappingWithBlock:(MapBlock)block {
    NSMutableArray *ret = [NSMutableArray arrayWithCapacity: [self count]];
    for (id value in self)
    {
        id mapValue = block(value);
        if (mapValue)
            [ret addObject: mapValue];
        else
        {
            NSAssert(NO, @"Skip nil object while mapping - can be logic error");
        }
    }
    return [NSArray arrayWithArray: ret];
}

- (id) valueByReducingWithBlock:(ReduceBlock)block {
    id ret = nil;
    for (id value in self)
        ret = block(ret, value);
    return ret;
}

- (NSArray *) arrayByFilteringWithBlock: (FilterBlock) block {
    NSMutableArray *ret = [NSMutableArray arrayWithCapacity: [self count]];
    for (id value in self)
        if (block(value))
            [ret addObject: value];
    return [NSArray arrayWithArray: ret];
}

- (NSArray *)objectsOfClass:(Class)cls {
    NSParameterAssert(cls);
    NSMutableArray *array = [@[] mutableCopy];
    for(id obj in self) if([obj isKindOfClass:cls]) [array addObject:obj];
    return [array copy];
}

@end