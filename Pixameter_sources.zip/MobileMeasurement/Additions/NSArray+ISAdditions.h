//
//  NSArray(ISAdditions)
//
//  Created by Vladimir Burylov on 5/11/12.
//  Copyright (c) 2012 Intellectsoft LTD. All rights reserved.
//

typedef id (^MapBlock)(id obj);
typedef id (^ReduceBlock)(id ret, id value);
typedef BOOL (^FilterBlock)(id obj);

@interface NSArray (ISAdditions)
- (NSArray *) arrayByMappingWithBlock: (MapBlock) block;
- (id) valueByReducingWithBlock: (ReduceBlock) block;
- (NSArray *) arrayByFilteringWithBlock: (FilterBlock) block;
- (NSArray *)objectsOfClass:(Class)cls;
@end