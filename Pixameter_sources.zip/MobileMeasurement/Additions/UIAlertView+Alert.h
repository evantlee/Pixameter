//
//  UIAlertView+Alert.h
//
//  Copyright 2011 Konstantin Salak. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSInteger const kUIAlertViewNoButtonIndex = 0;
static NSInteger const kUIAlertViewYesButtonIndex = 1;

static NSInteger const kUIAlertViewNotFoundIndex = NSNotFound;
static NSInteger const kUIAlertViewOkButtonIndex = 0;
static NSInteger const kUIAlertViewCancelButtonIndex = 1;
static NSInteger const kUIAlertViewDontShowButtonIndex = 1;
static NSInteger const kUIAlertViewDontShowButtonWithCancelIndex = 2;

typedef void(^UIAlertClickedBlock)(UIAlertView* alert, NSInteger buttonIndex);

@interface UIAlertView (Alert)

+ (void) alertWithTitle:(NSString*)title message:(NSString*)message;
+ (void) alertErrorWithMessage: (NSString*) message;
+ (void) alertErrorWithError: (NSError*)error;

+ (void) alertYesNoResultWithTitle:(NSString *)title message:(NSString *)message block:(UIAlertClickedBlock) finishBlock;
+ (void) alertWithTitle:(NSString*)title message:(NSString*)message block:(UIAlertClickedBlock) finishBlock;
+ (void) alertResultWithTitle:(NSString *)title message:(NSString *)message buttonNames:(NSArray *)buttonNames 
                        block:(UIAlertClickedBlock) finishBlock;
+ (void) alertResultWithTitle:(NSString *)title message:(NSString *)message cancelButton:(NSString *)cancel otherButton:(NSString *)other
                        block:(UIAlertClickedBlock) finishBlock;

@end
