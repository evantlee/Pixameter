//
//  KSDefines.h
//
//  Created by Konstantin Salak on 22/09/13.
//  Copyright (c) 2013 Konstantin Salak. All rights reserved.
//

#ifndef KSDefines_h
#define KSDefines_h

#define RGB(r, g, b) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1]
#define RGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

#define LOG_LEVEL_DEFAULT LOG_LEVEL_VERBOSE
#define LOG_LEVEL_DECLARATION static int ddLogLevel = LOG_LEVEL_DEFAULT;
#define DDLogVerboseTrace() DDLogVerbose(@"%@ : %s", [self class], __PRETTY_FUNCTION__)
#define PassCheckpoint(name) [TestFlight passCheckpoint:name]

#define ANIMATION_DURATION_DEFAULT 0.3f

#define DEFINE_SHARED_INSTANCE_USING_BLOCK(block) \
static dispatch_once_t pred = 0; \
__strong static id _sharedObject = nil; \
dispatch_once(&pred, ^{ \
_sharedObject = block(); \
}); \
return _sharedObject; \

#define iOS_7 ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
#define iOS_6 iOS_7 == NO
#define iOS_version [[[UIDevice currentDevice] systemVersion] floatValue]

#define IS_IPAD UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad
#define IS_IPHONE IS_IPAD == NO

#define NIB_NAME(__name__) IS_IPAD?[NSString stringWithFormat:@"%@_iPad",__name__]:__name__

#define EXCLUDE_LINE_COLOR RGB(237,20,91)

#endif

typedef enum:NSInteger{
    MMSolid = 0,
    MMDashed,
    MMOutsided,
} MMLineType;

typedef enum{
    MMMetricSystem = 0,
    MMEnglishSystem
} MMSystem;

typedef enum{
    MMAuto = 0,
    MMMilimeters,
    MMSantimeters,
    MMMeters,
    MMInches,
    MMFoots,
    MMYard
} MMSystemUnits;

typedef enum {
    MMRulerAuto,
    MMRulerManual
} MMRulerType;

#define NO_GROUP_NAME @"Noname"

#import "UIDevice+Hardware.h"

#define MMGlassSize          (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ? ([[UIDevice currentDevice] platformType] == UIDeviceMiniiPad ? 195 : 162) : 100)
#define MMCropSize           (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ? 100 : 50)
#define MMGlassOffsetX        10
#define MMGlassOffsetY       (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ? 80 : 55)

