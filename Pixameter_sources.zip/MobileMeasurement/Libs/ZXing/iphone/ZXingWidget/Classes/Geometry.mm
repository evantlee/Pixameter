//
//  Geometry.m
//  ZXingWidget
//
//  Created by Miroslav on 1/4/13.
//
//

#import "Geometry.h"

CGFloat ScalarProduct (CGPoint v1, CGPoint v2) {
    
    return v1.x*v2.x + v1.y*v2.y;
}

CGPoint MultiplyPointByNumber (CGPoint p, CGFloat d) {
    
    return CGPointMake(p.x*d, p.y*d);
}

CGPoint NormalizeVector (CGPoint v) {
    
    CGFloat d = sqrt(v.x*v.x + v.y*v.y);
    if (d == 0) return v;
    return CGPointMake(v.x/d, v.y/d);
}

CGPoint GetOrthogonalVector (CGPoint v) {
    
    return CGPointMake(v.y, -v.x);
}

CGFloat Dist (CGPoint p1, CGPoint p2) {
    
    return sqrt((p1.x-p2.x)*(p1.x-p2.x) + (p1.y-p2.y)*(p1.y-p2.y));
}

CGFloat Length (CGPoint v) {
    
    return sqrt(v.x*v.x + v.y*v.y);
}

CGFloat DistToSegment (CGPoint q, CGPoint p1, CGPoint p2) {
    
    if (p1.x == p2.x && p1.y == p2.y) return Dist(q,p1);
    
    CGFloat A = (p1.x-p2.x)*(p1.x-p2.x) + (p1.y-p2.y)*(p1.y-p2.y);
    CGFloat B = -2*(p1.x*p1.x + p1.y*p1.y + p2.x*q.x + p2.y*q.y - p1.x*(p2.x+q.x) - p1.y*(p2.y+q.y));
    CGFloat C = p1.x*p1.x + p1.y*p1.y + q.x*q.x + q.y*q.y - 2*p1.x*q.x - 2*p1.y*q.y;
    
    CGFloat t0 = -B/(2*A);
        
    if (t0 >= 0 && t0 <= 1) return sqrt(A*t0*t0 + B*t0 + C);
    return MIN(sqrt(A+B+C), sqrt(C)); // min(f(0),f(1))
}

CGPoint map90 (CGPoint point, CGRect rect) {
    
    CGPoint center;
    center.x = rect.size.width/2;
    center.y = rect.size.height/2;
    float x = point.x - center.x;
    float y = point.y - center.y;
    
    point.x = -y; point.y = x;
    point.x = point.x + center.x;
    point.y = point.y + center.y;
    return point;
}

BOOL isPointInBand (CGPoint q, CGPoint p1, CGPoint p2) {
    
    CGPoint v1 = CGPointMake(p2.x-p1.x,p2.y-p1.y);
    CGPoint v2 = CGPointMake(-v1.x,-v1.y);
    return ScalarProduct(CGPointMake(q.x-p1.x,q.y-p1.y), v1) >= 0 && ScalarProduct(CGPointMake(q.x-p2.x,q.y-p2.y), v2) >= 0;
}
