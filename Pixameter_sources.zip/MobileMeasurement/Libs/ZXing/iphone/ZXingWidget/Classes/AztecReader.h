//
//  AztecReader.h
//  ZXingWidget
//
//  Created by Lukas Stabe on 08.02.12.
//  Copyright (c) 2012 EOS UPTRADE GmbH. All rights reserved.
//

#import "FormatReader.h"

@interface AztecReader : FormatReader

- (id) init;

@end
