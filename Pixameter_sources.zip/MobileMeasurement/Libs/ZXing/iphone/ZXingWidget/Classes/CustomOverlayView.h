//
//  CustomOverlayView.h
//  ZXingWidget
//
//  Created by Miroslav on 1/3/13.
//
//

#import <UIKit/UIKit.h>

#import "OverlayView.h"

@interface CustomOverlayView : UIView {
	NSMutableArray *_points;
    UILabel *instructionsLabel;
	id<CancelDelegate> delegate;
	BOOL oneDMode;
    BOOL cancelEnabled;
    BOOL isValidRect;
    CGRect cropRect;
    NSString *displayedMessage;
}

@property (nonatomic, retain) NSMutableArray*  points;
@property (nonatomic, assign) id<CancelDelegate> delegate;
@property (nonatomic, assign) BOOL oneDMode;
@property (nonatomic, assign) CGRect cropRect;
@property (nonatomic, copy) NSString *displayedMessage;
@property (nonatomic, assign) BOOL cancelEnabled;
@property (readonly) BOOL isValidRect;
@property (nonatomic) CGPoint focusPoint;
@property (nonatomic) CGFloat focusSquareSize;

- (id)initWithFrame:(CGRect)theFrame cancelEnabled:(BOOL)isCancelEnabled oneDMode:(BOOL)isOneDModeEnabled showLicense:(BOOL)shouldShowLicense;
- (id)initWithFrame:(CGRect)theFrame cancelEnabled:(BOOL)isCancelEnabled oneDMode:(BOOL)isOneDModeEnabled;

- (void)setPoint:(CGPoint)point;
- (void)changeFocusRectParameters:(CGFloat)stamp;
- (void)resetFocusRectParameters;
- (CGPoint)map:(CGPoint)point;

@end
