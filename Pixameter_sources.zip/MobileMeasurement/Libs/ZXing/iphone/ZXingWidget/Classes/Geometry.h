//
//  Geometry.h
//  ZXingWidget
//
//  Created by Miroslav on 1/4/13.
//
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define MMS_IN_INCH 25.4


CGFloat ScalarProduct (CGPoint v1, CGPoint v2);
CGPoint MultiplyPointByNumber (CGPoint p, CGFloat d);
CGPoint NormalizeVector (CGPoint v);
CGPoint GetOrthogonalVector (CGPoint v);
CGFloat Dist (CGPoint p1, CGPoint p2);
CGFloat Length (CGPoint v);
CGFloat DistToSegment (CGPoint q, CGPoint p1, CGPoint p2);
CGPoint map90 (CGPoint p, CGRect rect); // copied from OverlayView
BOOL isPointInBand (CGPoint q, CGPoint p1, CGPoint p2);