// -*- Mode: ObjC; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*-

/**
 * Copyright 2009 Jeff Verkoeyen
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import "CustomOverlayView.h"
#import "Geometry.h"

static const CGFloat kPadding = 0;
static const CGFloat kLicenseButtonPadding = 10;
static const NSTimeInterval timeSquareHolds = 0.5;

static const CGPoint offset = CGPointMake(36,77);
CGFloat focusColor[4] = {0.0f, 1.0f, 0.0f, 0.7f};
BOOL colorIncrease = YES;

@interface CustomOverlayView()

@property (nonatomic,retain) NSDate *timeStamp;
@property (nonatomic,assign) UIButton *cancelButton;
@property (nonatomic,assign) UIButton *licenseButton;
@property (nonatomic,retain) UILabel *instructionsLabel;

@end


@implementation CustomOverlayView

@synthesize delegate, oneDMode;
@synthesize points = _points;
@synthesize licenseButton;
@synthesize cropRect;
@synthesize instructionsLabel;
@synthesize displayedMessage;
@synthesize cancelEnabled;
@synthesize timeStamp;
@synthesize isValidRect;
@synthesize focusPoint;
@synthesize focusSquareSize;

////////////////////////////////////////////////////////////////////////////////////////////////////
- (id)initWithFrame:(CGRect)theFrame cancelEnabled:(BOOL)isCancelEnabled oneDMode:(BOOL)isOneDModeEnabled {
    return [self initWithFrame:theFrame cancelEnabled:isCancelEnabled oneDMode:isOneDModeEnabled showLicense:YES];
}

- (id)initWithFrame:(CGRect)theFrame cancelEnabled:(BOOL)isCancelEnabled oneDMode:(BOOL)isOneDModeEnabled showLicense:(BOOL)showLicenseButton {
    self = [super initWithFrame:theFrame];
    if( self ) {
        
        CGFloat rectSize = self.frame.size.width - kPadding * 2;
        if (!oneDMode) {
            //cropRect = CGRectMake(kPadding, (self.frame.size.height - rectSize) / 2, rectSize, rectSize);
            //cropRect = CGRectMake(0,0,320,432);
            cropRect = CGRectMake(0,0,432,320);
        } else {
            CGFloat rectSize2 = self.frame.size.height - kPadding * 2;
            cropRect = CGRectMake(kPadding, kPadding, rectSize, rectSize2);
        }
        
        self.backgroundColor = [UIColor clearColor];
        self.oneDMode = isOneDModeEnabled;
        
        if (showLicenseButton) {
            self.licenseButton = [UIButton buttonWithType:UIButtonTypeInfoLight];
            
            CGRect lbFrame = [licenseButton frame];
            lbFrame.origin.x = self.frame.size.width - licenseButton.frame.size.width - kLicenseButtonPadding;
            lbFrame.origin.y = self.frame.size.height - licenseButton.frame.size.height - kLicenseButtonPadding;
            [licenseButton setFrame:lbFrame];
            [licenseButton addTarget:self action:@selector(showLicenseAlert:) forControlEvents:UIControlEventTouchUpInside];
            
            [self addSubview:licenseButton];
        }
        self.cancelEnabled = isCancelEnabled;
        self.timeStamp = [NSDate dateWithTimeIntervalSince1970:0];
        isValidRect = NO;
        focusPoint = CGPointZero;
        focusSquareSize = 40;
    }
    return self;
}

- (void)cancel:(id)sender {
	// call delegate to cancel this scanner
	if (delegate != nil) {
		[delegate cancelled];
	}
}

- (void)showLicenseAlert:(id)sender {
    
    NSString *title = NSLocalizedStringWithDefaultValue(@"OverlayView license alert title", nil, [NSBundle mainBundle], @"License", @"License");
    NSString *message = NSLocalizedStringWithDefaultValue(@"OverlayView license alert message", nil, [NSBundle mainBundle], @"Scanning functionality provided by ZXing library, licensed under Apache 2.0 license.", @"Scanning functionality provided by ZXing library, licensed under Apache 2.0 license.");
    NSString *cancelTitle = NSLocalizedStringWithDefaultValue(@"OverlayView license alert cancel title", nil, [NSBundle mainBundle], @"OK", @"OK");
    NSString *viewTitle = NSLocalizedStringWithDefaultValue(@"OverlayView license alert view title", nil, [NSBundle mainBundle], @"View License", @"View License");
    
    UIAlertView *av = [[UIAlertView alloc] initWithTitle:title message:message delegate:self cancelButtonTitle:cancelTitle otherButtonTitles:viewTitle, nil];
    [av show];
    [av release];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if (buttonIndex == [alertView firstOtherButtonIndex]) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.apache.org/licenses/LICENSE-2.0.html"]];
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
- (void) dealloc {
    
	[_points release];
    [instructionsLabel release];
    [displayedMessage release];
	[super dealloc];
}


- (void)drawRect:(CGRect)rect inContext:(CGContextRef)context {
    
	CGContextBeginPath(context);
	CGContextMoveToPoint(context, rect.origin.x, rect.origin.y);
	CGContextAddLineToPoint(context, rect.origin.x + rect.size.width, rect.origin.y);
	CGContextAddLineToPoint(context, rect.origin.x + rect.size.width, rect.origin.y + rect.size.height);
	CGContextAddLineToPoint(context, rect.origin.x, rect.origin.y + rect.size.height);
	CGContextAddLineToPoint(context, rect.origin.x, rect.origin.y);
	CGContextStrokePath(context);
}

- (void)changeFocusRectParameters:(CGFloat)stamp {
    
    if (focusSquareSize > 15) {
        
        focusSquareSize -= 30*stamp;
        if (focusSquareSize < 15) focusSquareSize = 15;
        //NSLog(@"%f",focusSquareSize);
    }
    if (colorIncrease) {
        
        focusColor[0] += 0.5;
        focusColor[2] += 0.5;
        if (focusColor[0] >= 1.0) colorIncrease = NO;
    }
    else {
        
        focusColor[0] -= 0.5;
        focusColor[2] -= 0.5;
        if (focusColor[0] <= 0.0) colorIncrease = YES;
    }
    //[self setNeedsDisplay];
}

- (void)resetFocusRectParameters {
    
    focusSquareSize = 40;
    colorIncrease = YES;
    focusColor[0] = focusColor[2] = 0.0;
}

- (void)drawFocusRectInContext:(CGContextRef)context {
    
    if (CGPointEqualToPoint(focusPoint,CGPointZero)) {
        return;
    }
    CGFloat size = MIN(focusSquareSize,30);
	CGContextBeginPath(context);
	CGContextMoveToPoint(context, focusPoint.x - size, focusPoint.y - size);
	CGContextAddLineToPoint(context, focusPoint.x + size, focusPoint.y - size);
	CGContextAddLineToPoint(context, focusPoint.x + size, focusPoint.y + size);
	CGContextAddLineToPoint(context, focusPoint.x - size, focusPoint.y + size);
	CGContextAddLineToPoint(context, focusPoint.x - size, focusPoint.y - size);
	CGContextStrokePath(context);
}

- (CGPoint)map:(CGPoint)point {
    
//    CGPoint center;
//    center.x = cropRect.size.width/2;
//    center.y = cropRect.size.height/2;
//    float x = point.x - center.x;
//    float y = point.y - center.y;
//    int rotation = 90;
//    switch(rotation) {
//        case 0:
//            point.x = x;
//            point.y = y;
//            break;
//        case 90:
//            point.x = -y;
//            point.y = x;
//            break;
//        case 180:
//            point.x = -x;
//            point.y = -y;
//            break;
//        case 270:
//            point.x = y;
//            point.y = -x;
//            break;
//    }
//    point.x = point.x + center.x;
//    point.y = point.y + center.y;
//    return point;
//    return CGPointMake(300-point.y,point.x);
    return point;
}

#define kTextMargin 10

////////////////////////////////////////////////////////////////////////////////////////////////////
- (void)drawRect:(CGRect)rect {
    
	[super drawRect:rect];
    CGContextRef c = UIGraphicsGetCurrentContext();
    
	CGContextSetStrokeColor(c, focusColor);
	CGContextSetFillColor(c, focusColor);
    CGContextSetLineWidth(c, 1.0);
	//[self drawRect:cropRect inContext:c];
    [self drawFocusRectInContext:c];
	
	CGContextSaveGState(c);

	if (nil != _points) {
        
		CGFloat blue[4] = {0.0f, 0.0f, 1.0f, 1.0f};
        CGFloat red[4] = {1.0f, 0.0f, 0.0f, 1.0f};
        CGContextSetLineWidth(c, 2.5);
            
        // MODIFIED: Draw one big square instead of 4 smalls. 
        CGFloat D = 7./36;
        CGPoint p1 = [[_points objectAtIndex:0] CGPointValue];
        CGPoint p2 = [[_points objectAtIndex:1] CGPointValue];
        CGPoint p3 = [[_points objectAtIndex:2] CGPointValue];
        CGPoint v12 = CGPointMake(p2.x-p1.x, p2.y-p1.y);
        CGPoint v32 = CGPointMake(p2.x-p3.x, p2.y-p3.y);
        
        //NSLog(@"SCALAR: %f",ScalarProduct(v12, v32));
        //NSLog(@"LENGTH: %f",fabs(Length(v12) - Length(v32)));
        
        //if (fabs(ScalarProduct(v12, v32)) < 100 && fabs(Length(v12) - Length(v32)) < 1) {
            
            CGContextSetStrokeColor(c, blue);
            CGContextSetFillColor(c, blue);
            isValidRect = YES;
//        }
//        else {
//            
//            CGContextSetStrokeColor(c, red);
//            CGContextSetFillColor(c, red);
//            isValidRect = NO;
//        }
        
        CGPoint vUp = MultiplyPointByNumber(v12, D);
        CGPoint vLeft = MultiplyPointByNumber(v32, D);
        CGPoint vDown = CGPointMake(-vUp.x, -vUp.y);
        CGPoint vRight = CGPointMake(-vLeft.x, -vLeft.y);
        
        CGPoint s1 = CGPointMake(p1.x+vDown.x+vLeft.x,p1.y+vDown.y+vLeft.y);
        CGPoint s2 = CGPointMake(p2.x+vUp.x+vLeft.x,p2.y+vUp.y+vLeft.y);
        CGPoint s3 = CGPointMake(p3.x+vUp.x+vRight.x,p3.y+vUp.y+vRight.y);
        CGPoint s4, p4;
        if ([_points count] < 4) {
            
            s4 = CGPointMake(p1.x-v32.x+vRight.x+vDown.x,p1.y-v32.y+vRight.y+vDown.y);
        }
        else {
            
            p4 = [[_points objectAtIndex:3] CGPointValue];
            s4 = CGPointMake(p4.x+12*(vRight.x+vDown.x)/7,p4.y+12*(vRight.y+vDown.y)/7);
        }
        
        CGPoint m1 = CGPointMake((s1.x+s2.x)/2+vLeft.x,(s1.y+s2.y)/2+vLeft.y);
        CGPoint m2 = CGPointMake((s2.x+s3.x)/2+vUp.x,(s2.y+s3.y)/2+vUp.y);
        CGPoint m3 = CGPointMake((s3.x+s4.x)/2+vRight.x,(s3.y+s4.y)/2+vRight.y);
        CGPoint m4 = CGPointMake((s4.x+s1.x)/2+vDown.x,(s4.y+s1.y)/2+vDown.y);
        
//        s1 = [self map:s1]; m1 = [self map:m1];
//        s2 = [self map:s2]; m2 = [self map:m2];
//        s3 = [self map:s3]; m3 = [self map:m3];
//        s4 = [self map:s4]; m4 = [self map:m4];
        
        CGContextBeginPath(c);
        CGContextMoveToPoint(c, cropRect.origin.x+s1.x, cropRect.origin.y+s1.y);
        CGContextAddLineToPoint(c, cropRect.origin.x+s2.x, cropRect.origin.y+s2.y);
        CGContextAddLineToPoint(c, cropRect.origin.x+s3.x, cropRect.origin.y+s3.y);
        CGContextAddLineToPoint(c, cropRect.origin.x+s4.x, cropRect.origin.y+s4.y);
        CGContextAddLineToPoint(c, cropRect.origin.x+s1.x, cropRect.origin.y+s1.y);
        CGContextStrokePath(c);
        
        CGContextBeginPath(c);
        CGContextMoveToPoint(c, cropRect.origin.x+(s1.x+s2.x)/2, cropRect.origin.y+(s1.y+s2.y)/2);
        CGContextAddLineToPoint(c, cropRect.origin.x+m1.x, cropRect.origin.y+m1.y);
        CGContextStrokePath(c);
        
        CGContextBeginPath(c);
        CGContextMoveToPoint(c, cropRect.origin.x+(s2.x+s3.x)/2, cropRect.origin.y+(s2.y+s3.y)/2);
        CGContextAddLineToPoint(c, cropRect.origin.x+m2.x, cropRect.origin.y+m2.y);
        CGContextStrokePath(c);
        
        CGContextBeginPath(c);
        CGContextMoveToPoint(c, cropRect.origin.x+(s3.x+s4.x)/2, cropRect.origin.y+(s3.y+s4.y)/2);
        CGContextAddLineToPoint(c, cropRect.origin.x+m3.x, cropRect.origin.y+m3.y);
        CGContextStrokePath(c);
        
        CGContextBeginPath(c);
        CGContextMoveToPoint(c, cropRect.origin.x+(s4.x+s1.x)/2, cropRect.origin.y+(s4.y+s1.y)/2);
        CGContextAddLineToPoint(c, cropRect.origin.x+m4.x, cropRect.origin.y+m4.y);
        CGContextStrokePath(c);
        
        //for testing correctness of centers of black squares
        
//        p1 = [self map:p1];
//        p2 = [self map:p2];
//        p3 = [self map:p3];
//        if ([_points count] >= 4) {
//            
//            p4 = [self map:p4];
//        }
//        
//        CGFloat R = 2;
//        CGContextBeginPath(c);
//        CGContextAddEllipseInRect(c, CGRectMake(cropRect.origin.x+p1.x-R,cropRect.origin.y+p1.y-R,2*R,2*R));
//        CGContextAddEllipseInRect(c, CGRectMake(cropRect.origin.x+p2.x-R,cropRect.origin.y+p2.y-R,2*R,2*R));
//        CGContextAddEllipseInRect(c, CGRectMake(cropRect.origin.x+p3.x-R,cropRect.origin.y+p3.y-R,2*R,2*R));
//        if ([_points count] >= 4) {
//         
//            CGContextAddEllipseInRect(c, CGRectMake(cropRect.origin.x+p4.x-R,cropRect.origin.y+p4.y-R,2*R,2*R));
//        }
//        CGContextFillPath(c);
        
//        CGContextBeginPath(c);
//        CGContextMoveToPoint(c, 0, 50);
//        CGContextAddLineToPoint(c, 320, 50);
//        CGContextMoveToPoint(c, 0, 100);
//        CGContextAddLineToPoint(c, 320, 100);
//        CGContextMoveToPoint(c, 0, 150);
//        CGContextAddLineToPoint(c, 320, 150);
//        CGContextMoveToPoint(c, 0, 200);
//        CGContextAddLineToPoint(c, 320, 200);
//        CGContextMoveToPoint(c, 0, 250);
//        CGContextAddLineToPoint(c, 320, 250);
//        CGContextMoveToPoint(c, 0, 300);
//        CGContextAddLineToPoint(c, 320, 300);
//        CGContextMoveToPoint(c, 0, 350);
//        CGContextAddLineToPoint(c, 320, 350);
//        CGContextMoveToPoint(c, 0, 400);
//        CGContextAddLineToPoint(c, 320, 400);
//        CGContextStrokePath(c);
	}
}


////////////////////////////////////////////////////////////////////////////////////////////////////
- (void)setPoints:(NSMutableArray*)pnts {
    
    //NSLog(@"%f",-[timeStamp timeIntervalSinceNow]);
    if (pnts != nil || (pnts == nil && [timeStamp timeIntervalSinceNow] < -timeSquareHolds)) {
        
        [pnts retain];
        [_points release];
        _points = pnts;
    
    //NSLog(@"SET POINTS: %@",_points);
    
        [self setNeedsDisplay];
    }
	
    if (pnts != nil) {
        //self.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.25];
        self.timeStamp = [NSDate date];
    }
}

- (void)setPoint:(CGPoint)point {
//    if (!_points) {
//        _points = [[NSMutableArray alloc] init];
//    }
//    if (_points.count > 3) {
//        [_points removeObjectAtIndex:0];
//    }
//    [_points addObject:[NSValue valueWithCGPoint:point]];
//    [self setNeedsDisplay];
}


@end
