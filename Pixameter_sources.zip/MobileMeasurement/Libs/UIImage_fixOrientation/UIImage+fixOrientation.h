//
//  UIImage+fixOrientation.h
//  MobileMeasurement
//
//  Created by Miroslav on 1/4/13.
//  Copyright (c) 2013 Ocsico. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface UIImage (fixOrientation)

- (UIImage *)fixOrientation;
+ (CGImageRef)CGImageRotated90:(CGImageRef)imgRef; // bad variant :(
+ (UIImage *)makeRoundedImage:(UIImage *)image radius:(CGFloat)radius;
+ (UIImage *)imageWithColor:(UIColor *)color;
+ (NSArray *)getRGBAsFromImage:(UIImage*)image atX:(int)xx andY:(int)yy count:(int)count;
+ (UIColor *)getRGBAsFromImage:(UIImage*)image atX:(int)xx andY:(int)yy;
+ (UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize;

@end
