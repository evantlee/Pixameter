//
//  NSString+measurementUnits.m
//  MobileMeasurement
//
//  Created by Miroslav on 2/18/13.
//  Copyright (c) 2013 OCSICO. All rights reserved.
//

#import "NSString+measurementUnits.h"

@implementation NSString (measurementUnits)

+ (NSString *)stringWithLengthInMillimeters:(CGFloat)millimeters {
    
    NSString *text;
    if ([MMState getDefaultScale] == 1) {
        
        if (millimeters < 10) {
            
            text = [NSString stringWithFormat:@"%.1f mm",millimeters];
        }
        else if (millimeters < 1000) {
            
            text = [NSString stringWithFormat:@"%.2f cm",millimeters/10];
        }
        else {
            
            text = [NSString stringWithFormat:@"%.2f m",millimeters/1000];
        }
    }
    else {
        
        CGFloat inches = millimeters / MMS_IN_INCH;
        if (inches < 12) {
            
            text = [NSString stringWithFormat:@"%.2f''", inches];
        }
        else {
            
            int feet = 0;
            while (inches >= 12) {
                
                inches -= 12;
                feet++;
            }
            text = [NSString stringWithFormat:@"%d' %.2f''",feet,inches];
        }
    }
    
    return text;
}

+ (MMRulerValue *)valueOfDistance:(float)distance inSystem:(MMSystem)system andUnits:(MMSystemUnits)units withDecimal:(int)decimal
{
    
    float value;
    NSString *stringUnits;
    NSString *fullStringValue;
    
    if (system == MMMetricSystem)
    {
        switch (units) {
            case MMMeters:
                value = distance / 1000.f;
                stringUnits = @"m";
                break;
            case MMSantimeters:
                value = distance / 10.f;
                stringUnits = @"cm";
                break;
            case MMMilimeters:
                value = distance;
                stringUnits = @"mm";
                break;
            default:
                if (distance < 10 )
                {
                    value = distance;
                    stringUnits = @"mm";
                    
                } else if (distance < 1000)
                {
                    value = distance / 10;
                    stringUnits = @"cm";
                    
                } else
                {
                    value = distance / 1000;
                    stringUnits = @"m";
                }
                break;
        }
    } else
    {
        distance = distance / MMS_IN_INCH;
        switch (units) {
            case MMInches:{
                value = distance;
                stringUnits = @"in";
                NSString *formater = [NSString stringWithFormat:@"%%.%if''",decimal];
                fullStringValue = [NSString stringWithFormat:formater,value];
                }
                break;
            case MMFoots:{
                value = distance/12;
                stringUnits = @"ft";
                NSString *formater = [NSString stringWithFormat:@"%%.%if'",decimal];
                fullStringValue = [NSString stringWithFormat:formater,value];
                }
                break;
            case MMYard:
                value = distance/36;
                stringUnits = @"yd";
                break;
            default:
                if (distance < 12 )
                {
                    value = distance;
                    stringUnits = @"in";
                    NSString *formater = [NSString stringWithFormat:@"%%.%if''",decimal];
                    fullStringValue = [NSString stringWithFormat:formater,distance];
                    
                } else if (distance < 36)
                {
                    
                    int feet = 0;
                    while (distance >= 12) {
                        
                        distance -= 12;
                        feet++;
                    }
                    fullStringValue = [NSString stringWithFormat:@"%d' %.2f''",feet,distance];
                    
                    
                } else
                {
                    value = distance / 36;
                    stringUnits = @"yd";
                }
                break;
        }
    }
    
    NSString *format = [NSString stringWithFormat:@"%%.%if",decimal];
    
    MMRulerValue *fullValue = [[MMRulerValue alloc] init];
    fullValue.value = [NSString stringWithFormat:format,value];
    fullValue.units = stringUnits;
    fullValue.valueInString = fullStringValue;
    
    return fullValue;
}

+ (MMRulerValue *)fixedValueOfDistance:(double)distance inSystem:(MMSystem)system andUnits:(MMSystemUnits)units
{
    NSString *stringUnits;
    if (system == MMMetricSystem) {
        switch (units) {
            case MMMeters:
                stringUnits = @"m";
                break;
            case MMSantimeters:
                stringUnits = @"cm";
                break;
            default:
                stringUnits = @"mm";
                break;
        }
    } else
    {
        switch (units) {
            case MMYard:
                stringUnits = @"yd";
                break;
            case MMFoots:
                stringUnits = @"'";
                break;
            default:
                stringUnits = @"''";
                break;
        }
    }
    
    
    MMRulerValue *fullValue = [[MMRulerValue alloc] init];
    fullValue.units = stringUnits;
    fullValue.value = [NSString floatToString:distance];
    return fullValue;
}

+ (NSString *) floatToString:(float) val {
    
	NSString *ret = [NSString stringWithFormat:@"%g", val];
//    NSRange isSpacedRange = [ret rangeOfString:@"." options:NSCaseInsensitiveSearch];
//    if(isSpacedRange.location != NSNotFound) {
//        unichar c = [ret characterAtIndex:[ret length] - 1];
//        while (c == 48 || c == 46) { // 0 or .
//            ret = [ret substringToIndex:[ret length] - 1];
//            c = [ret characterAtIndex:[ret length] - 1];
//        }
//    }
	return ret;
}

@end
