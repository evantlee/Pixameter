//
//  NSString+measurementUnits.h
//  MobileMeasurement
//
//  Created by Miroslav on 2/18/13.
//  Copyright (c) 2013 OCSICO. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MMState.h"
#import "Geometry.h"
#import "MMRulerValue.h"

@interface NSString (measurementUnits)

+ (NSString *)stringWithLengthInMillimeters:(CGFloat)millimeters;
+ (MMRulerValue *)valueOfDistance:(float)distance inSystem:(MMSystem)system andUnits:(MMSystemUnits)units withDecimal:(int)decimal;
+ (MMRulerValue *)fixedValueOfDistance:(double)distance inSystem:(MMSystem)system andUnits:(MMSystemUnits)units;
+ (NSString *) floatToString:(float) val;
@end
